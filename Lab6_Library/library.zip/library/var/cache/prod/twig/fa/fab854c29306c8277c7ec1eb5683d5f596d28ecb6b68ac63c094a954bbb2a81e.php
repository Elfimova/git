<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* book/_form.html.twig */
class __TwigTemplate_c2ba80b38022ebf52ae79c35b2383bbfdab582f2e95a0698458c4bb3cc275607 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "book/_form.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Добавить продукт";
    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "    ";
        // line 7
        echo "    ";
        echo twig_include($this->env, $context, "default/header.html.twig");
        echo "
    ";
        // line 9
        echo "    <div class=\"d-flex container container_optimalHeight align-items-center\" style=\"background-image:url('";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/images/3.jpg"), "html", null, true);
        echo "');\">
        <div class=\"d-flex container-fluid justify-content-center h-70\">
            ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["bookForm"] ?? null), 'form_start', ["attr" => ["class" => "d-flex flex-column w-50 justify-content-center"]]);
        echo "
            <h1 class=\"h1 mb-5 font-weight-normal text-center text-light\" style=\"padding-left: 120px;\"><span class=\"logo_red\"></span>Добавить книгу</h1>
            ";
        // line 13
        $context["formErrors"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "vars", [], "any", false, false, false, 13), "errors", [], "any", false, false, false, 13), "form", [], "any", false, false, false, 13), "getErrors", [0 => true], "method", false, false, false, 13);
        // line 14
        echo "            ";
        if (twig_length_filter($this->env, ($context["formErrors"] ?? null))) {
            // line 15
            echo "                <div class=\"alert alert-danger\">
                    <label>Исправьте следующие ошибки:</label>
                    <ul>
                        ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["formErrors"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 19
                echo "                            <li>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["error"], "message", [], "any", false, false, false, 19), "html", null, true);
                echo "</li>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 21
            echo "                    </ul>
                </div>
            ";
        }
        // line 24
        echo "            <div class=\"row mb-3 d-flex justify-content-around\">
                ";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "title", [], "any", false, false, false, 25), 'label', ["label_attr" => ["class" => "text-light text-right label_width_product"]] + (twig_test_empty($_label_ = twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "title", [], "any", false, false, false, 25)) ? [] : ["label" => $_label_]));
        echo "
                ";
        // line 26
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "title", [], "any", false, false, false, 26), 'widget', ["attr" => ["class" => "input_width form-control"]]);
        echo "
            </div>
            <div class=\"row mb-3 d-flex justify-content-around\">
                ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "author", [], "any", false, false, false, 29), 'label', ["label_attr" => ["class" => "text-light text-right label_width_product"]] + (twig_test_empty($_label_ = twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "author", [], "any", false, false, false, 29)) ? [] : ["label" => $_label_]));
        echo "
                ";
        // line 30
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "author", [], "any", false, false, false, 30), 'widget', ["attr" => ["class" => "input_width form-control"]]);
        echo "
            </div>
            <div class=\"row mb-3 d-flex justify-content-around\">
                ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "image", [], "any", false, false, false, 33), 'label', ["label_attr" => ["class" => "text-light"]] + (twig_test_empty($_label_ = twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "image", [], "any", false, false, false, 33)) ? [] : ["label" => $_label_]));
        echo "
                ";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "image", [], "any", false, false, false, 34), 'widget');
        echo "
            </div>
            <div class=\"row mb-3 d-flex justify-content-around\">
                ";
        // line 37
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "file", [], "any", false, false, false, 37), 'label', ["label_attr" => ["class" => "text-light"]] + (twig_test_empty($_label_ = twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "file", [], "any", false, false, false, 37)) ? [] : ["label" => $_label_]));
        echo "
                ";
        // line 38
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["bookForm"] ?? null), "file", [], "any", false, false, false, 38), 'widget');
        echo "
            </div>
            <div class=\"row justify-content-center mt-3\">
                <button class=\"btn btn-lg btn-dark col-6 btn_style\">";
        // line 41
        echo twig_escape_filter($this->env, (((isset($context["button_label"]) || array_key_exists("button_label", $context))) ? (_twig_default_filter(($context["button_label"] ?? null), "Добавить")) : ("Добавить")), "html", null, true);
        echo "</button>
            </div>
            ";
        // line 43
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["bookForm"] ?? null), 'form_end');
        echo "
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "book/_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 43,  147 => 41,  141 => 38,  137 => 37,  131 => 34,  127 => 33,  121 => 30,  117 => 29,  111 => 26,  107 => 25,  104 => 24,  99 => 21,  90 => 19,  86 => 18,  81 => 15,  78 => 14,  76 => 13,  71 => 11,  65 => 9,  60 => 7,  58 => 6,  54 => 5,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "book/_form.html.twig", "C:\\OSPanel\\domains\\library\\templates\\book\\_form.html.twig");
    }
}
