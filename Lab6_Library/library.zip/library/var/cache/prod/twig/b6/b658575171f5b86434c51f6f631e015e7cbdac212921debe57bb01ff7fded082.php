<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default/header.html.twig */
class __TwigTemplate_e203157cfba41be75cd7215b7827624db1ad9dc6252e30b02d6dd07dada61c95 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<header id=\"top\">
    <!-- ################################################################################################ -->
    <!-- ################################################################################################ -->
    <div class=\"wrapper row2\">
        <nav id=\"mainav\" class=\"hoc clear\">
            <div id=\"logo\" class=\"fl_left\">
                <h1><a href=\"/\">Книжный Рай</a></h1>
            </div>
            <div class=\"fl_right\">
                <ul class=\"clear\">
                    ";
        // line 11
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 11)) {
            // line 12
            echo "                        <li><a class=\"fa fa-user\" href=\"/\" >  ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 12), "name", [], "any", false, false, false, 12), "html", null, true);
            echo "</a> </li>
                        <li><a class=\"fa fa-book\" href=\"";
            // line 13
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("book_new");
            echo "\" > Добавить книгу </a></li>
                        <li><a class=\"fa fa-sign-out\" href=\"";
            // line 14
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\" > Выйти </a></li>
                    ";
        } else {
            // line 16
            echo "                        <li><a class=\"fa fa-sign-in\" href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_login");
            echo "\" >  Войти</a></li>
                        <li><a class=\"fa fa-pencil\" href=\"";
            // line 17
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_register");
            echo "\" >  Регистрация</a></li>
                    ";
        }
        // line 19
        echo "                </ul>
            </div>
        </nav>
    </div>
</header>";
    }

    public function getTemplateName()
    {
        return "default/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 19,  70 => 17,  65 => 16,  60 => 14,  56 => 13,  51 => 12,  49 => 11,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "default/header.html.twig", "C:\\OSPanel\\domains\\library\\templates\\default\\header.html.twig");
    }
}
